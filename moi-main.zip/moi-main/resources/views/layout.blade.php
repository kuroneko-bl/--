<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Конференции РФ</title>
    @vite(['resources/css/app.css'])
</head>
<body>
        <header>
        <h1>Мой сайт</h1>
    </header>
</body>
</html>